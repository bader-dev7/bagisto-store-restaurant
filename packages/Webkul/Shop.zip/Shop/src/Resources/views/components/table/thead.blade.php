<thead {{ $attributes->merge(['class' => '']) }}>
    {{ $slot }}
</thead>