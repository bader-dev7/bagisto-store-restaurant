<th {{ $attributes->merge(['class' => '']) }}>
    {{ $slot }}
</th>