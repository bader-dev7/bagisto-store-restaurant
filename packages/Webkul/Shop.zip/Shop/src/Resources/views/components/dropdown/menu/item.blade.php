<li {{ $attributes->merge(['class' => 'cursor-pointer px-5 py-2 text-base hover:bg-gray-100 max-sm:text-sm']) }}>
    {{ $slot }}
</li>