<tbody {{ $attributes->merge(['class' => '']) }}>
    {{ $slot }}
</tbody>