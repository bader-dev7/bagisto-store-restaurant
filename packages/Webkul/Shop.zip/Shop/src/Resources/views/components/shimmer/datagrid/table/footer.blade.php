<div class="flex items-center justify-between p-6">
    <div class="shimmer h-[18px] w-40"></div>

    <div>
        <ul class="inline-flex items-center -space-x-px">
            <div class="shimmer h-[30px] w-[35px]"></div>
            <div class="shimmer h-[30px] w-[35px]"></div>
            <div class="shimmer h-[30px] w-[35px]"></div>
        </ul>
    </div>
</div>