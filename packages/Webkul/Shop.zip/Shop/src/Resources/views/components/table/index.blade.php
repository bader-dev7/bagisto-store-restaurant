<table {{ $attributes->merge(['class' => '']) }}>
    {{ $slot }}
</table>