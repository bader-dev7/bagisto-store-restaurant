<label {{ $attributes->merge(['class' => 'mb-2 block text-base max-sm:text-sm max-sm:mb-1']) }}>
    {{ $slot }}
</label>
