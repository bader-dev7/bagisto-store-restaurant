<div class="mt-8 flex justify-start max-lg:hidden">
    <div class="flex items-center gap-x-3.5">
        @yield('breadcrumbs')
    </div>
</div>
