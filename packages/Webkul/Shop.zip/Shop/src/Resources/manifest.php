<?php

return [
    'name'    => 'Webkul Bagisto Shop',
    'version' => core()->version(),
];
