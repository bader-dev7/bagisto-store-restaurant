<?php

namespace Webkul\Shop\Http\Controllers\API;

use Webkul\Shop\Http\Controllers\Controller;

class APIController extends Controller {}
